// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using SpartanNash.REP.Application.Common.Interfaces;

namespace SpartanNash.SpartanNash.REP.Infrastructure.Common.Services;

public class DateTimeService : IDateTime
{
    public DateTime Now => DateTime.UtcNow;
}
