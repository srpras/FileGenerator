// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Domain.Enums;
using Microsoft.AspNetCore.Http;

namespace SpartanNash.REP.Infrastructure.Common.Services;

public class CurrentUserService : ICurrentUserService
{
    public CurrentUserService(IHttpContextAccessor httpContextAccessor)
    {
        if (httpContextAccessor.HttpContext?.User?.Identity?.IsAuthenticated ?? false)
        {

        }
    }
    public string? UserId { get; set; }
    public string? UserName { get; set; }
    public UserRole Role { get; set; }
}
