﻿using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Infrastructure.Common.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpartanNash.SpartanNash.REP.Infrastructure.Common.Services;

namespace SpartanNash.REP.Infrastructure.Extensions
{
    public static class IServiceCollectionExtensions
    {
        public static void AddInfrastructureLayer(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<ISerializer, SystemTextJsonSerializer>();
            services.AddSingleton<IDateTime, DateTimeService>();
            services.AddSingleton<ICurrentUserService, CurrentUserService>();
        }

    }
}
