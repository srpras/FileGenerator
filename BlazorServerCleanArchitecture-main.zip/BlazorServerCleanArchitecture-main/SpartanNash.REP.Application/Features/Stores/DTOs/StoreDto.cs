﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using SpartanNash.REP.Domain.Entities;
using System.ComponentModel;

namespace SpartanNash.REP.Application.Features.Stores.DTOs;

[Description("Stores")]
public class StoreDto
{
    [Description("Id")]
    public int Id { get; set; }
    [Description("Name")]
    public string Name { get; set; } = string.Empty;
    [Description("Description")]
    public string? Description { get; set; }


    private class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<Store, StoreDto>().ReverseMap();
        }
    }
}

