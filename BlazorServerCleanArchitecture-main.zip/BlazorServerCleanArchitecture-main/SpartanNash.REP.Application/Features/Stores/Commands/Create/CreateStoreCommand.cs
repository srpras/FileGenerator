﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.
using AutoMapper;
using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Application.Common.Models;
using SpartanNash.REP.Application.Features.Stores.DTOs;
using SpartanNash.REP.Domain.Entities;
using MediatR;
using SpartanNash.REP.Domain.Events;
using System.ComponentModel;

namespace SpartanNash.REP.Application.Features.Stores.Commands.Create;

public class CreateStoreCommand : IRequest<Result<int>>
{
    [Description("Id")]
    public int Id { get; set; }

    [Description("Name")]
    public string Name { get; set; } = string.Empty;

    private class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<StoreDto, CreateStoreCommand>(MemberList.None);
            CreateMap<CreateStoreCommand, Store>(MemberList.None);
        }
    }
}

public class CreateStoreCommandHandler : IRequestHandler<CreateStoreCommand, Result<int>>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;

    public CreateStoreCommandHandler(
        IApplicationDbContext context,
        IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<Result<int>> Handle(CreateStoreCommand request, CancellationToken cancellationToken)
    {
        var item = _mapper.Map<Store>(request);

        // raise a create domain event
        item.AddDomainEvent(new StoreCreatedEvent(item));
        _context.Stores.Add(item);
        await _context.SaveChangesAsync(cancellationToken);
        return await Result<int>.SuccessAsync(item.Id);
    }
}
