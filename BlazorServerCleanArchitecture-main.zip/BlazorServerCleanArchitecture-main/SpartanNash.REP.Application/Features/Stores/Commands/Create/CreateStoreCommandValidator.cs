﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using FluentValidation;

namespace SpartanNash.REP.Application.Features.Stores.Commands.Create;

public class CreateStoreCommandValidator : AbstractValidator<CreateStoreCommand>
{
    public CreateStoreCommandValidator()
    {

        RuleFor(v => v.Name)
             .MaximumLength(256)
             .NotEmpty();

    }

}

