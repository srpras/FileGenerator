﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Application.Common.Models;
using MediatR;
using Microsoft.EntityFrameworkCore;
using SpartanNash.REP.Domain.Events;

namespace SpartanNash.REP.Application.Features.Stores.Commands.Delete;

public class DeleteStoreCommand : IRequest<Result<int>>
{
    public int[] Id { get; }

    public DeleteStoreCommand(int[] id)
    {
        Id = id;
    }
}

public class DeleteStoreCommandHandler :
             IRequestHandler<DeleteStoreCommand, Result<int>>

{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;
    public DeleteStoreCommandHandler(
        IApplicationDbContext context,
         IMapper mapper
        )
    {
        _context = context;
        _mapper = mapper;
    }
    public async Task<Result<int>> Handle(DeleteStoreCommand request, CancellationToken cancellationToken)
    {
        var items = await _context.Stores.Where(x => request.Id.Contains(x.Id)).ToListAsync(cancellationToken);
        foreach (var item in items)
        {
            // raise a delete domain event
            item.AddDomainEvent(new StoreDeletedEvent(item));
            _context.Stores.Remove(item);
        }
        var result = await _context.SaveChangesAsync(cancellationToken);
        return await Result<int>.SuccessAsync(result);
    }

}

