﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.
using AutoMapper;
using SpartanNash.REP.Application.Common.ExceptionHandlers;
using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Application.Common.Models;
using SpartanNash.REP.Application.Features.Stores.DTOs;
using SpartanNash.REP.Domain.Entities;
using MediatR;
using SpartanNash.REP.Domain.Events;
using System.ComponentModel;

namespace SpartanNash.REP.Application.Features.Stores.Commands.Update;

public class UpdateStoreCommand : IRequest<Result<int>>
{
    [Description("Id")]
    public int Id { get; set; }

    [Description("Name")]
    public string Name { get; set; } = string.Empty;

    private class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<StoreDto, UpdateStoreCommand>(MemberList.None);
            CreateMap<UpdateStoreCommand, Store>(MemberList.None);
        }
    }
}

public class UpdateStoreCommandHandler : IRequestHandler<UpdateStoreCommand, Result<int>>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;
    public UpdateStoreCommandHandler(
        IApplicationDbContext context,
         IMapper mapper
        )
    {
        _context = context;
        _mapper = mapper;
    }
    public async Task<Result<int>> Handle(UpdateStoreCommand request, CancellationToken cancellationToken)
    {

        var item = await _context.Stores.FindAsync(new object[] { request.Id }, cancellationToken) ?? throw new NotFoundException($"Store with id: [{request.Id}] not found.");
        item = _mapper.Map(request, item);
        // raise a update domain event
        item.AddDomainEvent(new StoreUpdatedEvent(item));
        await _context.SaveChangesAsync(cancellationToken);
        return await Result<int>.SuccessAsync(item.Id);
    }
}

