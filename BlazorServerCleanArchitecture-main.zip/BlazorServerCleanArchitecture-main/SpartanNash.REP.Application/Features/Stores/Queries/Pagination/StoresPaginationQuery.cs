﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using AutoMapper.QueryableExtensions;
using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Application.Common.Models;
using SpartanNash.REP.Application.Features.Stores.DTOs;
using MediatR;
using System.Linq;

namespace SpartanNash.REP.Application.Features.Stores.Queries.Pagination;

public class StoresWithPaginationQuery : PaginationFilter, IRequest<PaginatedData<StoreDto>>
{
    
}

public class StoresWithPaginationQueryHandler :
         IRequestHandler<StoresWithPaginationQuery, PaginatedData<StoreDto>>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;
    public StoresWithPaginationQueryHandler(
        IApplicationDbContext context,
        IMapper mapper
        )
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<PaginatedData<StoreDto>> Handle(StoresWithPaginationQuery request, CancellationToken cancellationToken)
    {
        var data = await PaginatedData<StoreDto>.CreateAsync(_context.Stores.ProjectTo<StoreDto>(_mapper.ConfigurationProvider), 1, 10);

        return data;
    }
}