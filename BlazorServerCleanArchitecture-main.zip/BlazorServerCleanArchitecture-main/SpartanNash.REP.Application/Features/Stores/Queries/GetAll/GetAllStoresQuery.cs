﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using AutoMapper.QueryableExtensions;
using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Application.Features.Stores.DTOs;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace SpartanNash.REP.Application.Features.Stores.Queries.GetAll;

public class GetAllStoresQuery : IRequest<IEnumerable<StoreDto>>
{
    
}

public class GetAllStoresQueryHandler :
     IRequestHandler<GetAllStoresQuery, IEnumerable<StoreDto>>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;
    public GetAllStoresQueryHandler(
        IApplicationDbContext context,
         IMapper mapper
        )
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<IEnumerable<StoreDto>> Handle(GetAllStoresQuery request, CancellationToken cancellationToken)
    {
        var data = await _context.Stores
                     .ProjectTo<StoreDto>(_mapper.ConfigurationProvider)
                     .AsNoTracking()
                     .ToListAsync(cancellationToken);
        return data;
    }
}


