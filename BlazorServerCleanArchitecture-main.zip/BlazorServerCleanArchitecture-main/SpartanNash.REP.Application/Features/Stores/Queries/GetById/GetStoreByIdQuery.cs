﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using AutoMapper.QueryableExtensions;
using SpartanNash.REP.Application.Common.ExceptionHandlers;
using SpartanNash.REP.Application.Common.Interfaces;
using SpartanNash.REP.Application.Features.Stores.DTOs;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace SpartanNash.REP.Application.Features.Stores.Queries.GetById;

public class GetStoreByIdQuery : IRequest<StoreDto>
{
    public required int Id { get; set; }
}

public class GetStoreByIdQueryHandler :
     IRequestHandler<GetStoreByIdQuery, StoreDto>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;
    public GetStoreByIdQueryHandler(
        IApplicationDbContext context,
         IMapper mapper
        )
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<StoreDto> Handle(GetStoreByIdQuery request, CancellationToken cancellationToken)
    {
        var data = await _context.Stores.Where(i => i.Id == request.Id)
                     .ProjectTo<StoreDto>(_mapper.ConfigurationProvider)
                     .FirstOrDefaultAsync(cancellationToken) ?? throw new NotFoundException($"Store with id: [{request.Id}] not found.");
        return data;
    }
}
