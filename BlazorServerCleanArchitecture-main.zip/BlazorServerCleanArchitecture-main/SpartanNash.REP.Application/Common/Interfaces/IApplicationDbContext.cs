// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.


using SpartanNash.REP.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace SpartanNash.REP.Application.Common.Interfaces;

public interface IApplicationDbContext
{
    DbSet<AuditTrail> AuditTrails { get; set; }
    DbSet<DistributionList> DistributionLists { get; set; }
    DbSet<Store> Stores { get; set; }
    ChangeTracker ChangeTracker { get; }
    Task<int> SaveChangesAsync(CancellationToken cancellationToken);
}
