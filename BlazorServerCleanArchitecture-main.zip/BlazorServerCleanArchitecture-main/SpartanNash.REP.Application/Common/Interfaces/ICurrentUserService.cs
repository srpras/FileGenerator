// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using SpartanNash.REP.Domain.Enums;

namespace SpartanNash.REP.Application.Common.Interfaces;

public interface ICurrentUserService
{
    string? UserId { get; set; }
    string? UserName { get; set; }
    UserRole Role { get; set; }
}
