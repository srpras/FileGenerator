﻿using Microsoft.Extensions.DependencyInjection;
using SpartanNash.REP.Application.Common.Behaviours;
using MediatR;
using System.Reflection;
using SpartanNash.REP.Application.Common.PublishStrategies;

namespace SpartanNash.REP.Application.Extensions
{
    public static class IServiceCollectionExtensions
    {
        public static void AddApplicationLayer(this IServiceCollection services)
        {
            services.AddAutoMapper();
            services.AddMediator();
        }

        private static void AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(Assembly.GetExecutingAssembly());
        }

        private static void AddMediator(this IServiceCollection services)
        {
            services.AddMediatR(config => 
            {
                config.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
                config.NotificationPublisher = new ParallelNoWaitPublisher();
                config.AddOpenBehavior(typeof(PerformanceBehaviour<,>));
                config.AddOpenBehavior(typeof(UnhandledExceptionBehaviour<,>));
                config.AddOpenBehavior(typeof(ValidationBehaviour<,>));
                config.AddOpenBehavior(typeof(AuthorizationBehaviour<,>));
            });
        }    
    }
}
