# SpartanNash.REP
Building Blazor Server Apps with Clean Architecture - Demo Project for a blog post available at https://www.ezzylearning.net/tutorial/building-blazor-server-apps-with-clean-architecture
