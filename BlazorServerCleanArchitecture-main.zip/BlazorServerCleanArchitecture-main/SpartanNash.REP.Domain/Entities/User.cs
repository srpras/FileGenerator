﻿using SpartanNash.REP.Domain.Common;

namespace SpartanNash.REP.Domain.Entities
{
    public class User : BaseAuditableEntity
    { 
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public IReadOnlyCollection<Store> Stores { get; set; }
        public bool IsActive { get; set; }
    }
}
