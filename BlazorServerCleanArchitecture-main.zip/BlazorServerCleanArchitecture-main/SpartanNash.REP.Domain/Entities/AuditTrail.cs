﻿using SpartanNash.REP.Domain.Common;
using SpartanNash.REP.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpartanNash.REP.Domain.Entities
{
    public class AuditTrail : BaseEntity
    {
        public string? UserId { get; set; }
        public AuditType AuditType { get; set; }
        public string? TableName { get; set; }
        public DateTime DateTime { get; set; }
        public Dictionary<string, object?>? OldValues { get; set; }
        public Dictionary<string, object?>? NewValues { get; set; }
        public List<string>? AffectedColumns { get; set; }
    }
}
