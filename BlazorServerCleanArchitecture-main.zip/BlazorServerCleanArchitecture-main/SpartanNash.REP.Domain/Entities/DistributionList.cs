﻿using SpartanNash.REP.Domain.Common;

namespace SpartanNash.REP.Domain.Entities
{
    public class DistributionList : BaseAuditableEntity
    { 
        public string Name { get; set; }
        public bool IsActive { get; set; }
    }
}
