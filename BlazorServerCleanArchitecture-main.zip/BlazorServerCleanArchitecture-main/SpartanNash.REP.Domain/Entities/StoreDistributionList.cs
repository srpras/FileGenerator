﻿using SpartanNash.REP.Domain.Common;

namespace SpartanNash.REP.Domain.Entities
{
    public class StoreDistributionList : BaseAuditableEntity
    { 
        public string Email { get; set; }
        public Store Store { get; set; }
        public DistributionList DistributionList { get; set; }
        public bool IsSyncedToExo { get; set; }
        public bool IsActive { get; set; }
    }
}
