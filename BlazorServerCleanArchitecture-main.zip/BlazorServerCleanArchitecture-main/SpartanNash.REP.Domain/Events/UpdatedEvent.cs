using SpartanNash.REP.Domain.Common;
using SpartanNash.REP.Domain.Common.Interfaces;

namespace SpartanNash.REP.Domain.Events;
public class UpdatedEvent<T> : DomainEvent where T : IEntity
{
    public UpdatedEvent(T entity)
    {
        Entity = entity;
    }

    public T Entity { get; }
}
