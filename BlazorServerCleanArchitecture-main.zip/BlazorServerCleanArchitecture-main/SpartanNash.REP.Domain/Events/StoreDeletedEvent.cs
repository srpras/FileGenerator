﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using SpartanNash.REP.Domain.Common;
using SpartanNash.REP.Domain.Common.Interfaces;
using SpartanNash.REP.Domain.Entities;

namespace SpartanNash.REP.Domain.Events;

    public class StoreDeletedEvent : DomainEvent
    {
        public StoreDeletedEvent(Store item)
        {
            Item = item;
        }

        public Store Item { get; }
    }

