﻿namespace SpartanNash.REP.Domain.Common.Interfaces
{
    public interface IEntity
    {
        public int Id { get; set; }
    }
}
