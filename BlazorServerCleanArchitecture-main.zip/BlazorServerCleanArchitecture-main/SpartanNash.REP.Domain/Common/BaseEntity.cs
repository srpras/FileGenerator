﻿using SpartanNash.REP.Domain.Common.Interfaces;

using System.ComponentModel.DataAnnotations.Schema;

namespace SpartanNash.REP.Domain.Common
{
    public abstract class BaseEntity : IEntity
    {
        private readonly List<DomainEvent> _domainEvents = new();

        public int Id { get; set; }

        [NotMapped]
        public IReadOnlyCollection<DomainEvent> DomainEvents => _domainEvents.AsReadOnly();

        public void AddDomainEvent(DomainEvent domainEvent)
        {
            _domainEvents.Add(domainEvent);
        }

        public void RemoveDomainEvent(DomainEvent domainEvent)
        {
            _domainEvents.Remove(domainEvent);
        }

        public void ClearDomainEvents()
        {
            _domainEvents.Clear();
        }
    }
}
