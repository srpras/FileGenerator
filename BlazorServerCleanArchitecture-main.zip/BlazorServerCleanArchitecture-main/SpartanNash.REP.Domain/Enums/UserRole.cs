﻿namespace SpartanNash.REP.Domain.Enums
{
    public enum UserRole
    {
        Admin,
        User
    }
}
