﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ContosoUniversity.CustomFilters
{
    public class CustomExceptionAttribute : FilterAttribute, IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            filterContext.ExceptionHandled = true;
            filterContext.Controller.ViewBag.OnExceptionError = "Exception filter called";
            filterContext.HttpContext.Response.Write("Exception filter called");
                                 
        }
    }
}