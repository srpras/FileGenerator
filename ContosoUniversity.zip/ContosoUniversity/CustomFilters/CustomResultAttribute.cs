﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ContosoUniversity.CustomFilters
{
    public class CustomResultAttribute : FilterAttribute, IResultFilter
    {
       public void OnResultExecuted(ResultExecutedContext filterContext)
        {
            filterContext.Controller.ViewBag.OnResultExecuted = "OnResultExecuted filter called";
           
            filterContext.HttpContext.Response.Write("OnResultExecuted Also Called" + "<br/>");

            int a = 1;
            int b = 0;
            int result = a / b;
        }


       public void OnResultExecuting(ResultExecutingContext filterContext)
        {
            filterContext.Controller.ViewBag.OnResultExecuting = "OnResultExecuting filter called";
        }
    }
}